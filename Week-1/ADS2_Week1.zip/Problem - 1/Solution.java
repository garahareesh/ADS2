public class Solution {
    public static void main(String[] args) {
        
    }
}